//Text Model
class InterpretedText {
  
  String textID;
  String title;
  String interpretedText;

  InterpretedText(this.textID, this.title, this.interpretedText);
}