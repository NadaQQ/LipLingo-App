//Lesson Model
class Lesson {
  
  String lessonID;
  String level;
  String title;
  String videoPath;
  bool status;

  Lesson(this.lessonID, this.level, this.title, this.videoPath, this.status);
}