import 'levelModel.dart';

//Challenges Model
class Challenge{

  String challengeID;
  List<Level> levels;

  Challenge(this.challengeID, this.levels,);

}