//User Model
class Users {
  
  String userID;
  String firstName;
  String lastName;
  String email;
  String password;

  Users(this.userID, this.firstName, this.lastName, this.email, this.password);
}