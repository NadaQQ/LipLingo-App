//Level Model
class Level{

  String videoPath;
  List<String> choices;
  String correctChoice;

  Level(this.videoPath, this.choices, this.correctChoice);

}